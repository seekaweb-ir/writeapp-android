---
name: Important announcement
about: 'Please do not report here issues about Riot.imX. Report them on the RiotX
  project: https://github.com/vector-im/riotX-android'
title: ''
labels: ''
assignees: ''

---


