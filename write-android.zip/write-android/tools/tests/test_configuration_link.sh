#!/usr/bin/env bash

adb shell am start -a android.intent.action.VIEW -d "https://riot.im/config/config?hs_url=https%3A%2F%2Fexample.modular.im\&is_url=https%3A%2F%2Fcustom.identity.org"
