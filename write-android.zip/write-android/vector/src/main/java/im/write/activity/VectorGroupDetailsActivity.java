/*
 * Copyright 2014 OpenMarket Ltd
 * Copyright 2018 New Vector Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package im.write.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;

import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;
import org.matrix.androidsdk.MXSession;
import org.matrix.androidsdk.core.Log;
import org.matrix.androidsdk.core.MXPatterns;
import org.matrix.androidsdk.core.callback.ApiCallback;
import org.matrix.androidsdk.core.model.MatrixError;
import org.matrix.androidsdk.groups.GroupsManager;
import org.matrix.androidsdk.listeners.MXEventListener;
import org.matrix.androidsdk.rest.model.group.Group;

import java.util.List;

import im.write.Matrix;
import im.write.R;
import im.write.adapters.GroupDetailsFragmentPagerAdapter;
import im.write.ui.themes.ActivityOtherThemes;
import im.write.ui.themes.ThemeUtils;
import im.write.view.VectorViewPager;

/**
 *
 */
public class VectorGroupDetailsActivity extends MXCActionBarActivity {
    private static final String LOG_TAG = VectorRoomDetailsActivity.class.getSimpleName();

    // the group ID
    public static final String EXTRA_GROUP_ID = "EXTRA_GROUP_ID";
    public static final String EXTRA_TAB_INDEX = "VectorUnifiedSearchActivity.EXTRA_TAB_INDEX";

    // private classes
    private MXSession mSession;
    private GroupsManager mGroupsManager;
    private Group mGroup;

    // UI views
    private ProgressBar mGroupSyncInProgress;

    private VectorViewPager mPager;
    private GroupDetailsFragmentPagerAdapter mPagerAdapter;

    private MXEventListener mGroupEventsListener = new MXEventListener() {
        private void refresh(String groupId) {
            if ((null != mGroup) && TextUtils.equals(mGroup.getGroupId(), groupId)) {
                refreshGroupInfo();
            }
        }

        @Override
        public void onLeaveGroup(String groupId) {
            if ((null != mRoom) && TextUtils.equals(groupId, mGroup.getGroupId())) {
                finish();
            }
        }

        @Override
        public void onNewGroupInvitation(String groupId) {
            refresh(groupId);
        }

        @Override
        public void onJoinGroup(String groupId) {
            refresh(groupId);
        }


        @Override
        public void onGroupProfileUpdate(String groupId) {
            if ((null != mGroup) && TextUtils.equals(mGroup.getGroupId(), groupId)) {
                if (null != mPagerAdapter.getHomeFragment()) {
                    mPagerAdapter.getHomeFragment().refreshViews();
                }
            }
        }

        @Override
        public void onGroupRoomsListUpdate(String groupId) {
            if ((null != mGroup) && TextUtils.equals(mGroup.getGroupId(), groupId)) {
                if (null != mPagerAdapter.getRoomsFragment()) {
                    mPagerAdapter.getRoomsFragment().refreshViews();
                }

                if (null != mPagerAdapter.getHomeFragment()) {
                    mPagerAdapter.getHomeFragment().refreshViews();
                }
            }
        }

        @Override
        public void onGroupUsersListUpdate(String groupId) {
            if ((null != mGroup) && TextUtils.equals(mGroup.getGroupId(), groupId)) {
                if (null != mPagerAdapter.getPeopleFragment()) {
                    mPagerAdapter.getPeopleFragment().refreshViews();
                }

                if (null != mPagerAdapter.getHomeFragment()) {
                    mPagerAdapter.getHomeFragment().refreshViews();
                }
            }
        }

        @Override
        public void onGroupInvitedUsersListUpdate(String groupId) {
            onGroupUsersListUpdate(groupId);
        }
    };

    @Override
    public int getLayoutRes() {
        return R.layout.activity_vector_group_details;
    }

    @NotNull
    @Override
    public ActivityOtherThemes getOtherThemes() {
        return ActivityOtherThemes.Group.INSTANCE;
    }

    @Override
    public void initUiAndData() {
        configureToolbar();

        if (CommonActivityUtils.shouldRestartApp(this)) {
            Log.e(LOG_TAG, "Restart the application.");
            CommonActivityUtils.restartApp(this);
            return;
        }

        if (CommonActivityUtils.isGoingToSplash(this)) {
            Log.d(LOG_TAG, "onCreate : Going to splash screen");
            return;
        }

        Intent intent = getIntent();

        if (!intent.hasExtra(EXTRA_GROUP_ID)) {
            Log.e(LOG_TAG, "No group id");
            finish();
            return;
        }

        // get current session
        mSession = Matrix.getInstance(getApplicationContext()).getSession(intent.getStringExtra(EXTRA_MATRIX_ID));

        if ((null == mSession) || !mSession.isAlive()) {
            finish();
            return;
        }

        mGroupsManager = mSession.getGroupsManager();

        String groupId = intent.getStringExtra(EXTRA_GROUP_ID);

        if (!MXPatterns.isGroupId(groupId)) {
            Log.e(LOG_TAG, "invalid group id " + groupId);
            finish();
            return;
        }

        mGroup = mGroupsManager.getGroup(groupId);

        if (null == mGroup) {
            Log.d(LOG_TAG, "## onCreate() : displaying " + groupId + " in preview mode");
            mGroup = new Group(groupId);
        } else {
            Log.d(LOG_TAG, "## onCreate() : displaying " + groupId);
        }

        // UI widgets binding & init fields
        setWaitingView(findViewById(R.id.group_loading_layout));

        // tab creation and restore tabs UI context
        ActionBar actionBar = getSupportActionBar();

        if (null != actionBar) {
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mGroupSyncInProgress = findViewById(R.id.group_sync_in_progress);

        mPager = findViewById(R.id.groups_pager);
        mPagerAdapter = new GroupDetailsFragmentPagerAdapter(getSupportFragmentManager(), this);
        mPager.setAdapter(mPagerAdapter);

        TabLayout layout = findViewById(R.id.group_tabs);
        ThemeUtils.INSTANCE.setTabLayoutTheme(this, layout);

        if (intent.hasExtra(EXTRA_TAB_INDEX)) {
            mPager.setCurrentItem(getIntent().getIntExtra(EXTRA_TAB_INDEX, 0));
        } else {
            mPager.setCurrentItem(isFirstCreation() ? 0 : getSavedInstanceState().getInt(EXTRA_TAB_INDEX, 0));
        }
        layout.setupWithViewPager(mPager);

        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                // dismiss the keyboard when swiping
                final View view = getCurrentFocus();
                if (view != null) {
                    final InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    /**
     * @return the used group
     */
    public Group getGroup() {
        return mGroup;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        List<Fragment> allFragments = getSupportFragmentManager().getFragments();

        // dispatch the result to each fragments
        for (Fragment fragment : allFragments) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(EXTRA_TAB_INDEX, mPager.getCurrentItem());
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSession.getDataHandler().removeListener(mGroupEventsListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGroupInfo();
        mSession.getDataHandler().addListener(mGroupEventsListener);
    }

    /**
     * Refresh the group information
     */
    private void refreshGroupInfo() {
        if (null != mGroup) {
            mGroupSyncInProgress.setVisibility(View.VISIBLE);
            mGroupsManager.refreshGroupData(mGroup, new ApiCallback<Void>() {
                private void onDone() {
                    if (null != mGroupSyncInProgress) {
                        mGroupSyncInProgress.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onSuccess(Void info) {
                    onDone();
                }

                @Override
                public void onNetworkError(Exception e) {
                    onDone();
                }

                @Override
                public void onMatrixError(MatrixError e) {
                    onDone();
                }

                @Override
                public void onUnexpectedError(Exception e) {
                    onDone();
                }
            });
        }
    }
}
