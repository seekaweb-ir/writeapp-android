package im.write.listeners;

public interface ItemPositionChangedListener {
    void onItemPositionChangedListener(int position);
}
